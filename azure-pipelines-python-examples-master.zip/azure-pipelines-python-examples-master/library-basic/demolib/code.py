def example():
    return "banana!"