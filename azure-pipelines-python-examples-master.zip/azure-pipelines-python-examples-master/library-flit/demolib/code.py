"""Example module."""


def example():
    """Give a banana."""
    return "banana!"