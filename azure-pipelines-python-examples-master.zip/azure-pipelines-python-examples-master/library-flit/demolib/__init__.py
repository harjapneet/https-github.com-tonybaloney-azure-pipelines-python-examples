"""
Demo library for azure pipelines.

This package does nothing.
"""

__version__ = "0.0.1.dev"